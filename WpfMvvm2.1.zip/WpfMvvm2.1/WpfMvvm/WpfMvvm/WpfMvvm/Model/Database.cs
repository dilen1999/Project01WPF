﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfMvvm.Model
{
    public class Database:DbContext
    {
        public DbSet<student> Students { get; set; }
 
        private readonly string _path = @"D:\4 Th semi\WPF project\EG20203895\WpfMvvm2.1\WpfMvvm\WpfMvvm\WpfMvvm\DB\persons.db";

        protected override void
            OnConfiguring(DbContextOptionsBuilder optionsBuilder)
            => optionsBuilder.UseSqlite($"Data source={_path}");
    }
}
